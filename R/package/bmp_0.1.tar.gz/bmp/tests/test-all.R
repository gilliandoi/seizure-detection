library(testthat)
library(bmp)

test_package("bmp")